---
name: Kawaii Chaos
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0eded'
  surface-container-high: '#eae7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#574050'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#8a6f81'
  outline-variant: '#ddbed1'
  surface-tint: '#ad009b'
  primary: '#a90097'
  on-primary: '#ffffff'
  primary-container: '#d300bd'
  on-primary-container: '#fffbff'
  inverse-primary: '#fface8'
  secondary: '#5400c3'
  on-secondary: '#ffffff'
  secondary-container: '#7000ff'
  on-secondary-container: '#ddcdff'
  tertiary: '#00666d'
  on-tertiary: '#ffffff'
  tertiary-container: '#00818a'
  on-tertiary-container: '#f5feff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffd7f0'
  primary-fixed-dim: '#fface8'
  on-primary-fixed: '#3a0033'
  on-primary-fixed-variant: '#840076'
  secondary-fixed: '#e9ddff'
  secondary-fixed-dim: '#d1bcff'
  on-secondary-fixed: '#23005b'
  on-secondary-fixed-variant: '#5700c9'
  tertiary-fixed: '#7df4ff'
  tertiary-fixed-dim: '#00dbe9'
  on-tertiary-fixed: '#002022'
  on-tertiary-fixed-variant: '#004f54'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-xl:
    fontFamily: Bricolage Grotesque
    fontSize: 72px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Bricolage Grotesque
    fontSize: 40px
    fontWeight: '800'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Bricolage Grotesque
    fontSize: 32px
    fontWeight: '800'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Bricolage Grotesque
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '500'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '500'
    lineHeight: '1.6'
  label-bold:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '700'
    lineHeight: '1.0'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
  stack-gap: 16px
---

## Brand & Style

The design system is an explosion of hyper-expressive energy, blending the frantic visual language of shonen manga with the saturated sweetness of modern pop-art. It aims to evoke a sense of "maximum adorable madness"—an emotional response that is chaotic, joyful, and unapologetically loud. 

The aesthetic is a hybrid of **Neon-Brutalism** and **Manga Editorial**. It utilizes heavy line weights, halftone textures, and speed-line motifs to create a UI that feels like a living comic book. Every interaction should feel like a "pop," using high-contrast borders and vibrant depth to command attention. This system is designed for audiences who crave personality over corporate neutrality.

## Colors

The palette is built on "Extreme Neon" saturation to ensure the UI vibrates with energy. 
- **Primary (Neon Pink):** Used for main actions, high-energy highlights, and "kawaii" focal points.
- **Secondary (Electric Purple):** Used for depth, secondary branding, and rich backgrounds.
- **Tertiary (Cyan):** Used for informational accents, success states, and cooling down the warmer pinks.
- **Accent (Lemon Yellow):** Reserved for "Ultra-Pop" elements, warnings, or star-shaped decorations.
- **Neutral (Carbon Black):** Used for the heavy 4px and 8px borders (strokes) and deep drop shadows to provide structural grounding.

Backgrounds should frequently utilize pastel versions of these hues or halftone patterns (e.g., a faint pink dot grid on a white base).

## Typography

Typography is treated as a graphic element. 
- **Headlines:** Use **Bricolage Grotesque** for its quirky, expressive terminals. For top-level displays, always apply a **4px black stroke** and a **4px offset hard shadow** in a contrasting neon color.
- **Body:** **Plus Jakarta Sans** provides a friendly, rounded legibility that balances the chaos of the headlines.
- **Technical/Labels:** **Space Grotesk** adds a subtle "tech-manga" feel for metadata and buttons.

Text should never feel flat. Use frequent bolding, varied font sizes within the same paragraph for emphasis, and integrate emojis directly into headline strings.

## Layout & Spacing

The layout follows a **Fixed-Fluid Hybrid Grid**. While the main content containers are centered and maxed out at 1280px, the internal elements utilize a playful, non-linear arrangement.

- **The "Pop" Offset:** Elements do not sit perfectly flush. Use a spacing rhythm based on 8px increments, but allow for "floating" decorative elements (stars, sparkles) to break the grid.
- **Breakpoints:** 
    - **Mobile (<640px):** Single column, 16px margins. Borders reduce to 4px.
    - **Tablet (640px - 1024px):** 2-column flex, 24px margins.
    - **Desktop (>1024px):** 12-column grid with heavy use of asymmetric whitespace to mimic manga panels.
- **Gutters:** Maintain a wide 24px gutter to ensure the heavy borders of adjacent cards do not feel claustrophobic.

## Elevation & Depth

This design system rejects soft ambient shadows in favor of **Neo-Brutalist Hard Depth**.

- **Hard Shadows:** All interactive cards and buttons feature a non-blurred 8px (desktop) or 4px (mobile) shadow offset at a 45-degree angle. Shadow colors are usually the **Neutral (Black)** or a darker shade of the element's background color.
- **Stacking:** Higher "elevation" is communicated by increasing the thickness of the border and the distance of the hard shadow.
- **Halftone Blurs:** Instead of standard Gaussian blurs for background depth, use a **Halftone Pattern Overlay**. When a modal opens, the background should not just darken; it should gain a diagonal speed-line pattern or a thick dot-grid texture.

## Shapes

The shape language is "Bubbly but Structured."
- **Containers:** Use **rounded-lg (1rem)** for most cards and sections to maintain the friendly "kawaii" feel.
- **Buttons/Inputs:** Use **rounded-xl (1.5rem)** to create a squishy, touchable appearance.
- **Stamps:** Icons and decorative callouts should use a **Star-burst** or **Explosion** shape (8-point or 12-point polygons) with a thick black stroke.
- **Borders:** A consistent **4px solid black border** is required on all interactive elements. For primary containers or "Hero" sections, increase this to an **8px border**.

## Components

- **Buttons:** Must feature a "Pop" effect. On hover, the button’s hard shadow should shrink (offset moves from 8px to 2px) to simulate a physical press. Background colors should be Primary (Pink) or Tertiary (Cyan).
- **Cards:** Styled like manga panels. Every card must have a 4px black border. Use a white background with a subtle halftone dot pattern in the corner.
- **Speech Bubbles:** Used for tooltips, chat, and "System Alerts." These should feature a sharp "tail" and a 4px black stroke, mimicking comic dialogue.
- **Input Fields:** Rounded-xl with a 4px border. On focus, the border color changes to Primary (Pink) and the hard shadow grows larger.
- **Chips/Badges:** Pill-shaped with high-contrast colors (e.g., Lemon Yellow text on Black background). Include a small sparkle emoji (✨) next to the label.
- **Loading State:** Instead of a spinner, use a sequence of "Action Words" (e.g., "POW!", "WHAM!", "KA-CHING!") in a cycling animation.
- **Progress Bars:** Thick, 8px black border with a neon gradient fill that "pulses" in width.